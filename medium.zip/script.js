// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    
    // Sticky Header Effect
    function initStickyHeader() {
        const header = document.querySelector('.header');
        
        if (!header) {
            console.warn('Header element not found');
            return;
        }
        
        function handleScroll() {
            try {
                const scrollY = window.scrollY;
                const threshold = 50;
                
                if (scrollY > threshold) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            } catch (error) {
                console.error('Error in scroll handler:', error);
            }
        }
        
        // Add scroll event listener with throttling for better performance
        let ticking = false;
        
        function requestTick() {
            if (!ticking) {
                requestAnimationFrame(handleScroll);
                ticking = true;
                setTimeout(() => { ticking = false; }, 16); // ~60fps
            }
        }
        
        window.addEventListener('scroll', requestTick, { passive: true });
    }
    
    // Smooth scroll for anchor links
    function initSmoothScroll() {
        const links = document.querySelectorAll('a[href^="#"]');
        
        links.forEach(link => {
            link.addEventListener('click', function(e) {
                try {
                    const href = this.getAttribute('href');
                    const target = document.querySelector(href);
                    
                    if (target) {
                        e.preventDefault();
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                } catch (error) {
                    console.error('Error in smooth scroll:', error);
                }
            });
        });
    }
    
    // Add loading animation for images
    function initImageLoading() {
        const images = document.querySelectorAll('img');
        
        images.forEach(img => {
            if (img.complete) {
                img.classList.add('loaded');
            } else {
                img.addEventListener('load', function() {
                    this.classList.add('loaded');
                });
                
                img.addEventListener('error', function() {
                    console.warn('Failed to load image:', this.src);
                    this.style.display = 'none';
                });
            }
        });
    }
    
    // Add keyboard navigation support
    function initKeyboardNavigation() {
        const focusableElements = document.querySelectorAll(
            'a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])'
        );
        
        focusableElements.forEach(element => {
            element.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    if (this.tagName === 'A' || this.tagName === 'BUTTON') {
                        // Let default behavior handle the click
                        return;
                    }
                }
            });
        });
    }
    
    // Add hover effects for better UX
    function initHoverEffects() {
        const buttons = document.querySelectorAll('.cta-button, .nav-button');
        
        buttons.forEach(button => {
            button.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-1px)';
            });
            
            button.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });
    }
    
    // Initialize all functionality
    try {
        initStickyHeader();
        initSmoothScroll();
        initImageLoading();
        initKeyboardNavigation();
        initHoverEffects();
        
        console.log('Medium clone initialized successfully');
    } catch (error) {
        console.error('Error initializing Medium clone:', error);
    }
    
    // Add resize handler for responsive adjustments
    let resizeTimeout;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(function() {
            // Recalculate any size-dependent elements if needed
            console.log('Window resized, recalculating layout');
        }, 250);
    });
    
    // Performance monitoring (optional)
    if ('performance' in window) {
        window.addEventListener('load', function() {
            setTimeout(function() {
                const perfData = performance.getEntriesByType('navigation')[0];
                if (perfData) {
                    console.log('Page load time:', Math.round(perfData.loadEventEnd - perfData.fetchStart), 'ms');
                }
            }, 0);
        });
    }
});

// Export functions for potential testing or external use
window.MediumClone = {
    version: '1.0.0',
    initialized: true
};
